/*
Navicat MySQL Data Transfer

Source Server         : TestHbn
Source Server Version : 50018
Source Host           : localhost:3306
Source Database       : test

Target Server Type    : MYSQL
Target Server Version : 50018
File Encoding         : 65001

Date: 2013-09-08 16:38:48
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `user`
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `pw` varchar(50) character set utf8 NOT NULL,
  `un` varchar(50) character set utf8 NOT NULL,
  `ID` bigint(20) NOT NULL auto_increment,
  PRIMARY KEY  (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `USER` VALUES ('root', 'root', '1');
INSERT INTO `USER` VALUES ('guest', 'guest', '2');
