package DAO.operation.Impl;

import org.hibernate.*;
import org.hibernate.cfg.Configuration;

import DAO.User;
import DAO.operation.OperateData;

import java.util.*;

public class OperateDataImpl implements OperateData {


	public static SessionFactory sessionFactory;

	static {
		try {
			Configuration config = new Configuration();
			config.configure();//����hibernate.cfg.xml�����ļ�
			
			sessionFactory = config.buildSessionFactory();
		} catch (RuntimeException e) {
			e.printStackTrace();
			throw e;
		}

	}

	public List<User> getUserData() {
		Session session = sessionFactory.openSession();
		Transaction tx = null;
		List<User> userlist = new ArrayList<User>();
		try {
			tx = session.beginTransaction();
			Query query = session
					.createQuery("from User");
			List list = query.list();

			User gd;
			for (int i = 0; i < list.size(); i++) {
				gd = (User) list.get(i);
				userlist.add(gd);
			}
			tx.commit();

		} catch (RuntimeException e) {
			if (tx != null) {
				tx.rollback();

			}
			throw e;
		} finally {
			session.close();
		}
		return userlist;
	}

	public static void main(String args[]) {
		OperateData op = new OperateDataImpl();
		List<User> list = op.getUserData();
		
		for(User user: list){
			System.out.println(user.getId()+":"+user.getUserName()+ " " + user.getPassWord());
		}
	}

}
