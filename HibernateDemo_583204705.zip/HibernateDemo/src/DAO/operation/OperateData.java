/**
 * 
 */
package DAO.operation;

import java.util.List;


import DAO.User;

/**
 * @author Administrator
 *
 */
public interface OperateData {
	
	public List<User> getUserData();
	
	

}
